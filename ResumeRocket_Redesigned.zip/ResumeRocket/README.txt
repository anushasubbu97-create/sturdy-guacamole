ResumeRocket – Improved ATS Resume Builder
==========================================

WHAT'S NEW
- Refreshed, responsive interface with clearer visual hierarchy.
- Live resume completion indicator and improved resume checkup score.
- Added certifications section to the resume and editor.
- Improved keyword analysis with clearer matching/missing keyword groups.
- Automatic local draft saving plus manual Save draft action.
- Draft restoration when the page is reopened.
- Clear form action with confirmation.
- Character counter for the professional summary.
- Better input labels, keyboard focus states, accessibility labels and empty-section handling.
- More reliable PDF export with a print-to-PDF fallback.

RUN THE PROJECT
1. Extract the ZIP file.
2. Open the ResumeRocket folder in Visual Studio Code.
3. Open index.html in a browser, or use the VS Code Live Server extension.
4. Enter your details. The resume preview and completion indicator update as you type.
5. Select a template, optionally paste a target job description, and analyze keywords.
6. Download PDF to export your resume.

FILES
- index.html – page structure and editor controls
- style.css – responsive layout, visual styling and resume templates
- script.js – live preview, score checkup, keyword analysis, local saving and PDF export

NOTES
- Drafts are stored in LocalStorage in the same browser and on the same device.
- The PDF export library and Google Fonts are loaded from CDNs and may need an internet connection. If the PDF library is unavailable, use the browser print dialog and choose Save as PDF.
- The score is an educational checklist, not a real employer ATS score or a guarantee of selection.
- Keyword analysis uses simple text matching. It does not understand synonyms, context, or whether a keyword is genuinely supported by your experience. Add missing terms only when they accurately describe your skills.
- No resume data is sent to a server by this project.

REDESIGN UPDATE
- New home page: hero, features, 4-step guide, design picker, tips & FAQ.
- Minimalist design system: soft sage palette, Fraunces + Figtree typography, consistent spacing.
- Builder: Load sample, Export/Import backup (JSON), accent colour picker,
  5 resume designs (added Compact and Bold Header), Copy as plain text, Print,
  checkup suggestions, word/skill counts, keyword match percentage.
- Navigation uses #home / #builder in index.html. All earlier features are unchanged.
