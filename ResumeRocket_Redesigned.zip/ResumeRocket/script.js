const $ = id => document.getElementById(id);
const STORAGE_KEY = "resumerocket-draft-v2";
const formFields = ["name","title","email","phone","location","links","summary","skills","jobDescription"];
const lists = {education: $("educationList"), experience: $("experienceList"), project: $("projectList"), certification: $("certificationList")};
let saveTimer, accent="#3d6b5e";

const configs = {
  education: [["degree","Degree / course"],["school","College / university"],["year","Year / duration"],["details","Grade / details"]],
  experience: [["role","Job title"],["company","Company"],["period","Dates"],["details","Responsibilities / achievements"]],
  project: [["projectName","Project name"],["tech","Technologies"],["details","Project description"]],
  certification: [["certName","Certification name"],["issuer","Issuing organization"],["certYear","Year / credential"]]
};

function addEntry(type, values = {}) {
  const entry = document.createElement("div");
  entry.className = "entry"; entry.dataset.type = type;
  const head = document.createElement("div"); head.className = "entry-head";
  const number = document.createElement("span"); number.className = "entry-number"; number.textContent = `${type[0].toUpperCase()+type.slice(1)} entry`;
  const remove = document.createElement("button"); remove.type = "button"; remove.className = "remove-btn"; remove.textContent = "Remove";
  remove.setAttribute("aria-label", `Remove ${type} entry`);
  remove.addEventListener("click", () => { entry.remove(); updatePreview(); scheduleAutosave(); });
  head.append(number, remove);
  const fields = document.createElement("div"); fields.className = "fields two";
  configs[type].forEach(([key, label]) => {
    const wrap = document.createElement("label"); wrap.textContent = label;
    const input = key === "details" ? document.createElement("textarea") : document.createElement("input");
    if (key === "details") input.rows = 2;
    input.dataset.key = key; input.placeholder = label; input.value = values[key] || "";
    input.addEventListener("input", () => { updatePreview(); scheduleAutosave(); });
    wrap.appendChild(input); fields.appendChild(wrap);
  });
  entry.append(head, fields); lists[type].appendChild(entry); updatePreview();
}
function getEntries(type) {
  return [...lists[type].querySelectorAll(".entry")].map(entry => {
    const data = {}; entry.querySelectorAll("[data-key]").forEach(input => data[input.dataset.key] = input.value.trim()); return data;
  }).filter(item => Object.values(item).some(Boolean));
}
function esc(value) { return String(value || "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function itemHTML(title, meta, details) {
  if (![title,meta,details].some(Boolean)) return "";
  return `<div class="resume-item">${title ? `<strong>${esc(title)}</strong>` : ""}${meta ? `<p class="meta">${esc(meta)}</p>` : ""}${details ? `<p class="description">${esc(details)}</p>` : ""}</div>`;
}
function renderList(type, target, emptyText, titleFn, metaFn, detailFn) {
  const items = getEntries(type);
  $(target).innerHTML = items.length ? items.map(x => itemHTML(titleFn(x),metaFn(x),detailFn(x))).join("") : `<p class="placeholder">${emptyText}</p>`;
  const section = $(target).closest(".resume-section"); if (section) section.hidden = !items.length;
}
function updatePreview() {
  const val = id => $(id).value.trim();
  $("pName").textContent = val("name") || "Your Name";
  $("pTitle").textContent = val("title") || "Your Professional Title";
  $("pContact").textContent = [val("email"),val("phone"),val("location"),val("links")].filter(Boolean).join("  ·  ") || "Email · Phone · Location · LinkedIn";
  $("pSummary").textContent = val("summary") || "Your professional summary will appear here.";
  $("pSummary").classList.toggle("placeholder", !val("summary"));
  $("pSkills").textContent = val("skills") || "Your skills will appear here.";
  $("pSkills").classList.toggle("placeholder", !val("skills"));
  $("summarySection").hidden = !val("summary"); $("skillsSection").hidden = !val("skills");
  renderList("experience","pExperience","Your work experience will appear here.",x=>x.role,x=>[x.company,x.period].filter(Boolean).join(" | "),x=>x.details);
  renderList("education","pEducation","Your education will appear here.",x=>x.degree,x=>[x.school,x.year].filter(Boolean).join(" | "),x=>x.details);
  renderList("project","pProjects","Your projects will appear here.",x=>x.projectName,x=>x.tech,x=>x.details);
  renderList("certification","pCertifications","Your certifications will appear here.",x=>x.certName,x=>[x.issuer,x.certYear].filter(Boolean).join(" | "),()=>"");
  $("resumePreview").className = `resume ${$("template").value}`;
  $("summaryCount").textContent = val("summary").length;
  $("wordCount").textContent=($("resumePreview").innerText.match(/\S+/g)||[]).length; $("skillCount").textContent=val("skills").split(/[,\n]/).filter(x=>x.trim()).length;
  updateCompletion(); calculateScore(false);
}
function updateCompletion() {
  const val = id => $(id).value.trim();
  const completed = [!!val("name"),!!val("title"),!!val("email"),!!val("phone"),!!val("summary"),getEntries("education").length>0,getEntries("experience").length>0,getEntries("project").length>0,!!val("skills")];
  const pct = Math.round(completed.filter(Boolean).length/completed.length*100);
  $("completionText").textContent = `${pct}% complete`; $("completionBar").style.width = `${pct}%`;
  $("completionHint").textContent = pct===100 ? "Great start — review your content and export when ready." : "Complete your key details and sections to build a stronger resume.";
}
function calculateScore(showMessage = true) {
  const val = id => $(id).value.trim();
  const experience = getEntries("experience"), education = getEntries("education"), projects = getEntries("project"), certs = getEntries("certification");
  const skills = val("skills").split(/[,\n]/).map(s=>s.trim()).filter(Boolean);
  const checks = [
    [!!val("name") && !!val("email") && !!val("phone"),15], [!!val("title"),8], [!!val("summary") && val("summary").length>=50,12],
    [education.length>0,12], [experience.length>0,15], [projects.length>0,10], [skills.length>=3,12],
    [!!val("location") && !!val("links"),5],
    [experience.some(x=>/\d+%|\d+\+|\$\s?\d+|\b(increased|reduced|saved|managed|led|delivered)\b/i.test(x.details)),6],
    [certs.length>0,5]
  ];
  const tipText=["Add your name, email and phone","Add a professional title","Write a summary of 50+ characters","Add an education entry","Add work experience","Add at least one project","List 3 or more skills","Add location and a LinkedIn/portfolio link","Add a measurable result (a number or action verb) to experience","Add a certification"];
  $("scoreTips").innerHTML=checks.map(([ok],i)=>ok?"":`<li>${tipText[i]}</li>`).join("")||"<li class=\"ok\">All checks passed. Review wording and keep it to one page.</li>";
  const score = checks.reduce((sum,[ok,points])=>sum+(ok?points:0),0);
  $("score").textContent = score; $("scoreBar").style.width = `${score}%`;
  $("scoreLabel").textContent = score>=85 ? "Strong foundation" : score>=65 ? "Good progress" : score>=40 ? "Room to improve" : "Add your details";
  if(showMessage) toast(`Resume checkup: ${score}/100`);
  return score;
}
function toast(message) { const t=$("toast"); t.textContent=message; t.classList.add("show"); clearTimeout(toast.timer); toast.timer=setTimeout(()=>t.classList.remove("show"),2400); }
function collectData() {
  const data={}; formFields.forEach(id=>data[id]=$(id).value); data.template=$("template").value; data.accent=accent;
  Object.keys(lists).forEach(type=>data[type]=getEntries(type)); return data;
}
function saveDraft(showToast=true) {
  try { localStorage.setItem(STORAGE_KEY,JSON.stringify(collectData())); $("saveState").innerHTML='<span class="status-dot"></span> Saved on this device'; if(showToast)toast("Draft saved on this device."); }
  catch(error) { console.warn("Draft could not be saved",error); if(showToast)toast("Could not save. Check browser storage settings."); }
}
function scheduleAutosave() { $("saveState").innerHTML='<span class="status-dot" style="background:#e3a43b"></span> Unsaved changes'; clearTimeout(saveTimer); saveTimer=setTimeout(()=>saveDraft(false),700); }
function loadDraft() {
  try {
    const raw=localStorage.getItem(STORAGE_KEY); if(!raw)return;
    const data=JSON.parse(raw); formFields.forEach(id=>{if(typeof data[id]==="string")$(id).value=data[id];});
    $("template").value=data.template||"modern"; if(data.accent)setAccent(data.accent);
    Object.keys(lists).forEach(type=>{lists[type].innerHTML="";(Array.isArray(data[type])?data[type]:[]).forEach(item=>addEntry(type,item));});
    $("saveState").innerHTML='<span class="status-dot"></span> Draft restored';
  } catch(error) { console.warn("Saved draft could not be restored",error); }
}
function tokenize(text) { return (text.toLowerCase().match(/[a-z][a-z+#.]{1,}/g)||[]).map(w=>w.replace(/[.,]+$/,"")); }
function matchKeywords() {
  const job=$("jobDescription").value.trim(); const output=$("keywordResults");
  if(!job) { output.innerHTML='<p class="keyword-summary">Paste a job description first to see matching terms.</p>'; return; }
  const resume=[$("title").value,$("summary").value,$("skills").value,...Object.keys(lists).flatMap(type=>getEntries(type).flatMap(x=>Object.values(x)))].join(" ").toLowerCase();
  const stop=new Set("the and for with you our are will that this from have has your job work team years year who all any able about into their they use using experience skills role must should can candidate ability strong including preferred required knowledge looking seeking responsible responsibilities qualifications such plus across ensure support develop build".split(" "));
  const words=tokenize(job); const counts=new Map(); words.forEach(w=>{if(w.length>2&&!stop.has(w))counts.set(w,(counts.get(w)||0)+1);});
  const keywords=[...counts.keys()].sort((a,b)=>counts.get(b)-counts.get(a)).slice(0,40);
  const found=keywords.filter(w=>resume.includes(w)); const missing=keywords.filter(w=>!resume.includes(w));
  const pct=keywords.length?Math.round(found.length/keywords.length*100):0;
  output.innerHTML=`<p class="keyword-summary"><strong>${pct}%</strong> keyword match</p><div class="meter"><i style="width:${pct}%"></i></div><p class="keyword-summary"><strong>${found.length}</strong> matching terms · <strong>${missing.length}</strong> terms to review</p><div class="tag-list">${found.map(w=>`<span class="tag">${esc(w)} ✓</span>`).join("")}${missing.map(w=>`<span class="tag missing">${esc(w)} +</span>`).join("")}</div><p class="keyword-legend">Green = found in your resume · Amber = consider adding only if it accurately reflects your experience.</p>`;
}
function clearResume() {
  $("resumeForm").reset(); Object.values(lists).forEach(list=>list.innerHTML="");
  Object.keys(lists).forEach(type=>addEntry(type)); $("keywordResults").innerHTML="";
  localStorage.removeItem(STORAGE_KEY); $("template").value="modern"; updatePreview();
  $("saveState").innerHTML='<span class="status-dot"></span> Changes are local'; toast("Resume form cleared.");
}
function downloadPDF() {
  const element=$("resumePreview"); const options={margin:0,filename:"ResumeRocket-Resume.pdf",image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:true,backgroundColor:"#ffffff"},jsPDF:{unit:"mm",format:"a4",orientation:"portrait"},pagebreak:{mode:["css","legacy"]}};
  if(window.html2pdf) { window.html2pdf().set(options).from(element).save().catch(()=>{toast("PDF export failed. Opening print dialog.");window.print();}); }
  else { toast("PDF library unavailable. Use Print → Save as PDF."); window.print(); }
}
formFields.forEach(id=>$(id).addEventListener("input",()=>{updatePreview();scheduleAutosave();}));
$("template").addEventListener("change",()=>{updatePreview();scheduleAutosave();});
$("addEducation").addEventListener("click",()=>addEntry("education"));
$("addExperience").addEventListener("click",()=>addEntry("experience"));
$("addProject").addEventListener("click",()=>addEntry("project"));
$("addCertification").addEventListener("click",()=>addEntry("certification"));
$("saveBtn").addEventListener("click",()=>saveDraft(true));
$("evaluateBtn").addEventListener("click",()=>calculateScore(true));
$("matchBtn").addEventListener("click",matchKeywords);
$("downloadBtn").addEventListener("click",downloadPDF);
$("clearBtn").addEventListener("click",()=>$("clearDialog").showModal());
$("confirmClear").addEventListener("click",event=>{event.preventDefault();$("clearDialog").close();clearResume();});
loadDraft();
Object.keys(lists).forEach(type=>{if(!getEntries(type).length)addEntry(type);});
updatePreview();

/* ---- navigation between home and builder ---- */
function route(){
  const id=(location.hash||"#home").slice(1); const view=id==="builder"?"builder":"home";
  document.body.dataset.view=view;
  document.querySelectorAll(".nav a").forEach(a=>a.classList.toggle("active",a.dataset.nav===(view==="builder"?"builder":(["features","faq"].includes(id)?id:"home"))));
  if(view==="home"&&["features","faq"].includes(id))requestAnimationFrame(()=>$(id).scrollIntoView());
  else window.scrollTo(0,0);
}
window.addEventListener("hashchange",route); route();

/* ---- accent colour ---- */
function setAccent(color){
  accent=color; $("resumePreview").style.setProperty("--ra",color);
  document.querySelectorAll(".sw").forEach(b=>b.setAttribute("aria-pressed",b.dataset.accent===color));
}
document.querySelectorAll(".sw").forEach(b=>b.addEventListener("click",()=>{setAccent(b.dataset.accent);scheduleAutosave();}));
setAccent(accent);

/* ---- template shortcuts on home ---- */
document.querySelectorAll("[data-tpl]").forEach(b=>b.addEventListener("click",()=>{$("template").value=b.dataset.tpl;updatePreview();scheduleAutosave();location.hash="#builder";}));

/* ---- sample data ---- */
const SAMPLE={name:"Alex Chen",title:"Full-Stack Developer",email:"alex.chen@email.com",phone:"+91 98765 43210",location:"Hyderabad, India",links:"linkedin.com/in/alexchen",
  summary:"Computer science graduate with hands-on experience building responsive web apps in React and Node.js. Delivered projects used by 500+ students and improved page load time by 35%.",
  skills:"JavaScript, React, Node.js, HTML, CSS, SQL, Git, REST APIs, Problem solving",
  experience:[{role:"Web Development Intern",company:"BrightLabs",period:"Jun 2025 - Aug 2025",details:"Built 6 reusable React components used across 3 products.\nReduced API response time by 28% by adding caching."}],
  education:[{degree:"B.Tech, Computer Science (AI & ML)",school:"Your University",year:"2022 - 2026",details:"CGPA 8.4"}],
  project:[{projectName:"Campus Events Portal",tech:"React, Node.js, MongoDB",details:"Event discovery app with login, search and RSVP. Delivered to 500+ students."}],
  certification:[{certName:"Responsive Web Design",issuer:"freeCodeCamp",certYear:"2025"}]};
function loadSample(){
  formFields.forEach(id=>{if(typeof SAMPLE[id]==="string")$(id).value=SAMPLE[id];});
  Object.keys(lists).forEach(t=>{lists[t].innerHTML="";SAMPLE[t].forEach(v=>addEntry(t,v));});
  updatePreview(); scheduleAutosave(); location.hash="#builder"; toast("Sample resume loaded. Replace it with your details.");
}
document.querySelectorAll("[data-sample]").forEach(b=>b.addEventListener("click",loadSample));

/* ---- backup export / import ---- */
$("exportBtn").addEventListener("click",()=>{
  const blob=new Blob([JSON.stringify(collectData(),null,2)],{type:"application/json"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="resumerocket-backup.json"; a.click(); URL.revokeObjectURL(a.href); toast("Backup downloaded.");
});
$("importBtn").addEventListener("click",()=>$("importFile").click());
$("importFile").addEventListener("change",e=>{
  const f=e.target.files[0]; if(!f)return; const r=new FileReader();
  r.onload=()=>{try{const d=JSON.parse(r.result);
    formFields.forEach(id=>{if(typeof d[id]==="string")$(id).value=d[id];});
    $("template").value=d.template||"modern"; if(d.accent)setAccent(d.accent);
    Object.keys(lists).forEach(t=>{lists[t].innerHTML="";(Array.isArray(d[t])?d[t]:[]).forEach(v=>addEntry(t,v));if(!getEntries(t).length)addEntry(t);});
    updatePreview(); scheduleAutosave(); toast("Backup imported.");}catch{toast("That file is not a valid ResumeRocket backup.");}};
  r.readAsText(f); e.target.value="";
});

/* ---- copy plain text / print ---- */
$("copyTextBtn").addEventListener("click",async()=>{
  const el=$("resumePreview").cloneNode(true); el.querySelectorAll("[hidden]").forEach(n=>n.remove());
  const text=[...el.querySelectorAll("h1,h2,h3,p,strong")].map(n=>n.tagName==="H3"?"\n"+n.textContent.toUpperCase():n.textContent).join("\n").replace(/\n{3,}/g,"\n\n").trim();
  try{await navigator.clipboard.writeText(text);toast("Plain-text resume copied.");}catch{toast("Copy is blocked by the browser. Use Download PDF instead.");}
});
$("printBtn").addEventListener("click",()=>window.print());
